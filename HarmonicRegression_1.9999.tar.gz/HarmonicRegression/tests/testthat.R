library(testthat)
library(HarmonicRegression)

test_check("HarmonicRegression")
