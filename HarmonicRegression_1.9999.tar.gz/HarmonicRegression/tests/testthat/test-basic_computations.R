context("Check basic computations")

data("rna.polya")

rna.mat <- t(as.matrix(rna.polya[1:200, -1]))
timepoints <- as.numeric(
  regmatches(names(rna.polya)[-1],
             regexpr("\\d+", names(rna.polya)[-1]))) 

rna.mat.na <- rna.mat
rna.mat.na[3, 1] <- NA


test_reg <- stats::lm(rna.mat[, 1] ~ cos(pi/12*timepoints) + 
                        sin(pi/12*timepoints),
                      x = TRUE)
ssx <- t(test_reg$x) %*% test_reg$x
test_reg_sum <- summary(test_reg)


## double check identical model matrices for LS and robust versions
rest.fit <- stats::lm(rna.mat[, 1] ~ poly(timepoints, 2, raw = TRUE),
                      na.action = na.exclude)
unrest.fit <- stats::update(rest.fit, . ~ 
                              cos(pi/12*timepoints) + sin(pi/12*timepoints) + .,
                            x = TRUE)

unrest.fit_r <- Rfit::rfit(rna.mat[, 1] ~ 
                             cos(pi/12*timepoints) + sin(pi/12*timepoints) + 
                             poly(timepoints, 2, raw = TRUE))




## code directly from print.summary.lm
test_pval <- stats::pf(test_reg_sum$fstatistic[1L], 
                       test_reg_sum$fstatistic[2L], 
                       test_reg_sum$fstatistic[3L], 
                       lower.tail = FALSE)
                         

hreg <- harmonic.regression(rna.mat, timepoints)


test_that("Standard harmonic regression p value is correctly computed", {
  expect_equal(hreg$pvals[1], test_pval, check.attributes = FALSE)
})

test_that("QR inverse works correctly as implemented", {
  expect_equal(solve(ssx), chol2inv(qr.R(test_reg$qr)), 
               check.attributes = FALSE)
})

test_that("Amplitude CI code works as expected", {
  ## This formula directly from Halberg et al. 1967
  amp_vars <- 2*hreg$ssr/9/12
  expect_equal(amp_vars, (hreg$ci$amp/2)^2, check.attributes = FALSE)
})

test_that("Phase CI code works as expected", {
  ## This formula directly from Halberg et al. 1967
  phi_vars <- 2*hreg$ssr/9/(12*hreg$pars$amp^2)
  expect_equal(ifelse(phi_vars < (pi/2)^2, phi_vars, (pi/2)^2), 
               (hreg$ci$phi/2)^2, check.attributes = FALSE)
})

test_that("Model matrices are constructed as expected", {
  expect_equal(unrest.fit$x, unrest.fit_r$x, check.attributes = FALSE)
})
