context("Check against old")

load("oldbench_polya.rdata")
data("rna.polya")

rna.mat <- t(as.matrix(rna.polya[1:200, -1]))
timepoints <- as.numeric(
  regmatches(names(rna.polya)[-1],
             regexpr("\\d+", names(rna.polya)[-1]))) 

rna.mat.na <- rna.mat
rna.mat.na[3, 1] <- NA


expect_hreg_equal <- function (oldreg, newreg, what) {
  if (is.null(oldreg[[what]]) || is.null(newreg[[what]]))
    stop("Incorrect output element name")
  if (is.null(oldreg[["qvals"]]) || is.null(newreg[["pvals_ost"]]))
    stop("Incorrect package versions")
  eval(bquote(expect_equal(oldreg[[.(what)]], newreg[[.(what)]],
                           check.attributes = FALSE)))
}

expect_batch <- function (oldreg, newreg){
  expect_hreg_equal(oldreg, newreg, "means")
  expect_hreg_equal(oldreg, newreg, "fit.vals")
  expect_hreg_equal(oldreg, newreg, "coeffs")
  expect_hreg_equal(oldreg, newreg, "df")
  expect_hreg_equal(oldreg, newreg, "pvals")
  expect_hreg_equal(oldreg, newreg, "pars")
  expect_hreg_equal(oldreg, newreg, "ssr")
  expect_hreg_equal(oldreg, newreg, "ci")
}

## since a bug in the code for computing confidence intervals for the case of
## trend elimination, CIs are not included when testing here (test would and
## should always fail)
expect_batch_noci <- function (oldreg, newreg){
  expect_hreg_equal(oldreg, newreg, "means")
  expect_hreg_equal(oldreg, newreg, "fit.vals")
  expect_hreg_equal(oldreg, newreg, "coeffs")
  expect_hreg_equal(oldreg, newreg, "df")
  expect_hreg_equal(oldreg, newreg, "pvals")
  expect_hreg_equal(oldreg, newreg, "pars")
  expect_hreg_equal(oldreg, newreg, "ssr")
}
  
argument_defs <- list(
  standard = list(),
  np   = list(norm.pol = TRUE, norm.pol.degree = 2),
  t    = list(trend.eliminate = TRUE, trend.degree = 2),
  npt  = list(norm.pol = TRUE, norm.pol.degree = 2,
              trend.eliminate = TRUE, trend.degree = 2),
  a    = list(normalize = FALSE),
  at   = list(normalize = FALSE,
              trend.eliminate = TRUE, trend.degree = 2)
  # r    = list(robust = TRUE),
  # rnp  = list(robust = TRUE,
  #             norm.pol = TRUE, norm.pol.degree = 2),
  # rt   = list(robust = TRUE,
  #             trend.eliminate = TRUE, trend.degree = 2),
  # rnpt = list(robust = TRUE,
  #             norm.pol = TRUE, norm.pol.degree = 2,
  #             trend.eliminate = TRUE, 
  #             trend.degree = 2),
  # ra   = list(robust = TRUE,
  #             normalize = FALSE),
  # rat  = list(robust = TRUE,
  #             normalize = FALSE,
  #             trend.eliminate = TRUE, 
  #             trend.degree = 2)
)

perform_test <- function (code, nas, trend) {
  if (nas == FALSE) {
    variable_name <- paste("res", code, sep = "_")
    arguments <- c(list(inputts = rna.mat, inputtime = timepoints),
                   argument_defs[[code]])
    tres <- do.call("harmonic.regression", arguments)
  }
  else {
    variable_name <- paste("res", code, "na", sep = "_")
    arguments <- c(list(inputts = rna.mat.na, inputtime = timepoints),
                   argument_defs[[code]])
    tres <- do.call("harmonic.regression", arguments)
  }
  if (trend)
    expect_batch_noci(get(variable_name), tres)
  else
    expect_batch(get(variable_name), tres)
  
}


test_that("outputs match: standard", {
  perform_test("standard", nas = FALSE, trend = FALSE)
})

test_that("outputs match: np", {
  perform_test("np", nas = FALSE, trend = FALSE)
})

test_that("outputs match: t", {
  perform_test("t", nas = FALSE, trend = TRUE)
})

test_that("outputs match: npt", {
  perform_test("npt", nas = FALSE, trend = TRUE)
})

test_that("outputs match: a", {
  perform_test("a", nas = FALSE, trend = FALSE)
})

test_that("outputs match: at", {
  perform_test("at", nas = FALSE, trend = TRUE)
})


test_that("outputs match: standard NAs", {
  perform_test("standard", nas = TRUE, trend = FALSE)
})

test_that("outputs match: np NAs", {
  perform_test("np", nas = TRUE, trend = FALSE)
})

test_that("outputs match: t NAs", {
  perform_test("t", nas = TRUE, trend = TRUE)
})

test_that("outputs match: npt NAs", {
  perform_test("npt", nas = TRUE, trend = TRUE)
})

test_that("outputs match: a NAs", {
  perform_test("a", nas = TRUE, trend = FALSE)
})

test_that("outputs match: at NAs", {
  perform_test("at", nas = TRUE, trend = TRUE)
})


# Testing of robust code for internal incremental purpose only:
# robust version not included in previous published version

# test_that("outputs match: r", {
#   perform_test("r", nas = FALSE, trend = FALSE)
# })
# 
# test_that("outputs match: rnp", {
#   perform_test("rnp", nas = FALSE, trend = FALSE)
# })

# test_that("outputs match: rt", {
#   perform_test("rt", nas = FALSE, trend = TRUE)
# })

# test_that("outputs match: rnpt", {
#   perform_test("rnpt", nas = FALSE, trend = TRUE)
# })

# test_that("outputs match: ra", {
#   perform_test("ra", nas = FALSE, trend = FALSE)
# })
# 
# test_that("outputs match: rat", {
#   perform_test("rat", nas = FALSE, trend = TRUE)
# })

# test_that("outputs match: r NAs", {
#   perform_test("r", nas = TRUE, trend = FALSE)
# })
# 
# test_that("outputs match: rnp NAs", {
#   perform_test("rnp", nas = TRUE, trend = FALSE)
# })

# test_that("outputs match: rt NAs", {
#   perform_test("rt", nas = TRUE, trend = TRUE)
# })

# test_that("outputs match: rnpt NAs", {
#   perform_test("rnpt", nas = TRUE, trend = TRUE)
# })

# test_that("outputs match: ra NAs", {
#   perform_test("ra", nas = TRUE, trend = FALSE)
# })
# 
# test_that("outputs match: rat NAs", {
#   perform_test("rat", nas = TRUE, trend = TRUE)
# })
# 




